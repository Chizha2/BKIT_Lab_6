﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_6
{
    class Program
    {
        delegate double MultiplyOrDivide(double p1, double p2); // определение делегата

        static double Multiply(double p1, double p2) // первый экземпляр делегата
        {
            return p1 * p2;
        }

        static double Divide(double p1, double p2) // второй экземпляр делегата
        {
            return p1 / p2;
        }

        static void MultiplyorDivideMethod(string str, double i1, double i2, MultiplyOrDivide MultiplyOrDivideParam) // метод, принимающий делегат / лямбда-выражение
        {
            double Result = MultiplyOrDivideParam(i1, i2);
            Console.WriteLine(str + Result.ToString());
        }

        static void MultiplyOrDivideMethodFunc(string str, double i1, double i2, Func<double, double, double> MultiplyOrDivideParam) // метод, принимающий обобщенный делегат
        {
            double Result = MultiplyOrDivideParam(i1, i2);
            Console.WriteLine(str + Result.ToString());
        }

        static void Main(string[] args)
        {
            MultiplyorDivideMethod("Деление: ", 7, 6, Divide); // вызов метода (в качестве параметра - второй экземпляр делегата)
            MultiplyorDivideMethod("Остаток от деления: ", 17, 3, (double x, double y) => { double z = x % y; return z; } ); // вызов метода (в качестве параметра - лямбда-выражение)
            MultiplyOrDivideMethodFunc("Среднее арифметическое: ", 15, 4, (x, y) => (x + y) / 2); // вызов метода (в качестве параметра - обощенный делегат)

            Console.ReadLine();
        }
    }
}