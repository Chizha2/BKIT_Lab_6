﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Lab_6_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Вывод информации о сборке:");
            Assembly i = Assembly.GetExecutingAssembly();
            Console.WriteLine("Информация:" + i.DefinedTypes); // ?

            Console.ReadLine();
        }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = false)]
    public class NewAttribute : Attribute // Класс атрибута
    {
        public NewAttribute() { }
        public NewAttribute(string DescriptionParam) { Description = DescriptionParam; }
        public string Description { get; set; }
    }

    public class Circle
    {
        private double _Radius = 0; // радиус
        private string _Size = "Неизвестно"; // размер

        public double Radius // описание радиуса
        {
            get
            {
                return _Radius;
            }
            set
            {
                if (value > 0)
                    _Radius = value;
            }
        }

        public string Size // описание размера
        {
            get
            {
                return _Size;
            }
            set
            {
                _Size = value;
            }
        }

        public Circle(double radius_intro) // конструктор_1
        {
            Radius = radius_intro;
        }

        public Circle(string size_intro) // конструктор_2
        {
            Size = size_intro;
        }

        public Circle(double radius_intro, string size_intro) // конструктор_3
        {
            Radius = radius_intro;
            Size = size_intro;
        }

        public double Area() // площадь
        {
            return Math.PI * Radius * Radius;
        }

        public override string ToString() // формирование строки
        {
            string temp = "Радиус: " + Radius + " Площадь: " + Area();
            return temp;
        }

        public void Print() // печать
        {
            Console.WriteLine(ToString());
            Console.WriteLine();
        }
    }
}
